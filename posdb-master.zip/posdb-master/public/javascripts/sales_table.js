$(document).ready(function() {
  $('#sales_table').dataTable({
    "order": [[ 5, "desc" ]]
  });
});
