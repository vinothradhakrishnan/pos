$(document).ready(function() {
  $('#tblProducts').dataTable();
});
